# Frieren: Eternal Journey — Player Web

A minimal, cream-and-sage player dashboard built with Next.js App Router. It is designed to share the existing MongoDB database with the Railway Baileys RPG bot.

## Included

- Player sign-in by one-time WhatsApp code.
- Optional password sign-in, enabled after a successful WhatsApp-code sign-in.
- Character overview and profile, synced from the existing `Player` collection.
- Daily allowance claim (120 EG).
- NPC shop for the bot's Health Potion and Mana Potion.
- Player-to-player market: list one owned item, buy another player's active listing.
- Inventory and transaction history.
- HTTP-only, signed, seven-day session cookie.
- Server-side database access; no MongoDB credentials in browser code.

## Important integration notes

This website is a player portal, not a replacement for the persistent WhatsApp bot. Keep the Baileys process running on Railway. Deploy this Next.js website to Vercel.

The website expects the same MongoDB database and the existing `Player` and `Transaction` collections used by the starter bot. It re-declares those schemas to match the existing bot model fields. Do not change the bot's `userId` format: the bot stores the digits-only WhatsApp phone number, and the website uses that same format.

### 1. Add the WhatsApp `.webcode` command to the Railway bot

The code command must be added to the existing bot so it can privately send a login code and save only a hash in MongoDB.

Add this model to `src/database/models.js` in the bot:

```js
const webLoginCodeSchema = new mongoose.Schema({
  userId: { type: String, required: true, index: true },
  codeHash: { type: String, required: true, index: true },
  expiresAt: { type: Date, required: true, index: { expires: 0 } },
  consumedAt: { type: Date, default: null }
}, { timestamps: true });

export const WebLoginCode = mongoose.models.WebLoginCode
  || mongoose.model('WebLoginCode', webLoginCodeSchema);
```

Add `WEB_CODE_SECRET` to the Railway bot's environment variables. Use the exact same value in Vercel. Make it a long random secret (at least 24 characters). Never put it in a `NEXT_PUBLIC_` variable.

In `src/commands/handler.js`, add these imports:

```js
import { randomInt, createHmac } from 'node:crypto';
import { WebLoginCode } from '../database/models.js';
```

Inside the command handler's `try` / command switch, add the `webcode` case. Use the existing `userId` and `jid` variables already present in that handler:

```js
case 'webcode': {
  if (jid.endsWith('@g.us')) {
    return reply(sock, jid, 'For account safety, request your web code in a private chat with the bot.', message);
  }
  const secret = process.env.WEB_CODE_SECRET;
  if (!secret || secret.length < 24) {
    return reply(sock, jid, 'Web sign-in is not configured yet.', message);
  }
  const code = String(randomInt(0, 1000000)).padStart(6, '0');
  const codeHash = createHmac('sha256', secret).update(code).digest('hex');
  await WebLoginCode.deleteMany({ userId, consumedAt: null });
  await WebLoginCode.create({
    userId,
    codeHash,
    expiresAt: new Date(Date.now() + 10 * 60 * 1000)
  });
  return reply(sock, jid, `✧ Your Frieren web sign-in code: ${code}\\nExpires in 10 minutes. Never share this code.`, message);
}
```

If the bot handler uses a different switch shape, insert the case in its existing command dispatch rather than replacing the handler. The case must run only after the handler has resolved the sender's digits-only `userId`. Do not expose codes in group chats or logs.

### 2. MongoDB setup

- Use the same MongoDB Atlas database name/URI for the Railway bot and Vercel app.
- Ensure the cluster is a replica set (MongoDB Atlas clusters are replica-set capable). The shop and market use MongoDB transactions to keep currency and inventory updates atomic.
- Add Vercel's outbound database connectivity as required by your Atlas network access settings. Avoid broad public access if your setup supports a narrower allow-list.
- Back up the database before first production use.

### 3. Run locally

Requirements: Node.js 20.11 or newer.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Fill `.env.local` with:
- `MONGODB_URI` — same database as the bot.
- `AUTH_SECRET` — random secret, 32+ characters.
- `WEB_CODE_SECRET` — same exact secret configured on Railway.
- `NEXT_PUBLIC_APP_URL` — local URL while testing.

Open `http://localhost:3000`.

### 4. Deploy to Vercel

1. Push this project folder to a GitHub repository. Keep `.env.local` out of Git; it is ignored.
2. Open https://vercel.com/new and import that repository.
3. Framework preset should be **Next.js**. Root Directory should be the folder containing this `package.json`.
4. In Project → Settings → Environment Variables, add:
   - `MONGODB_URI`
   - `AUTH_SECRET`
   - `WEB_CODE_SECRET`
   - `NEXT_PUBLIC_APP_URL` (your Vercel URL)
5. Apply variables to Production (and Preview if you intend to test previews).
6. Deploy. After changing environment variables, redeploy for changes to take effect.
7. Test with a player account already registered in the WhatsApp bot:
   - Send `.webcode` privately to the bot.
   - Enter the phone number in international digits-only format and the six-digit code on the website.
   - Claim the daily reward and confirm the same EG balance changes in the WhatsApp bot.

### 5. Security and operating notes

- Never expose `MONGODB_URI`, `AUTH_SECRET`, or `WEB_CODE_SECRET` to client-side code or `NEXT_PUBLIC_` variables.
- The website uses HTTP-only signed cookies and bcrypt password hashes.
- A password can only be created after WhatsApp-code authentication.
- Codes expire after ten minutes and are single-use.
- Use HTTPS in production. Vercel provides HTTPS for deployed domains.
- Market, NPC shop and daily rewards update the same MongoDB player balance as the bot.
- The market transfers one item and EG between two players using a transaction. A listing consumes one item at creation; sold listings cannot be purchased again.
- Do not use real money or payment details in this fictional currency market.
- Add a dedicated account-recovery and code-request rate-limit workflow before opening the portal to a large public audience. For production at scale, add database-backed throttling for OTP/password attempts, CSRF/origin checks, audit logs and monitoring.
- The existing bot's `.daily` reward and the website's daily reward share the `dailyClaimAt` field. Both channels therefore compete for the same daily claim rather than granting two rewards.
- Vercel serverless functions are not suitable for keeping the Baileys socket alive. Keep the bot on Railway.

## Current scope

This is a complete initial player portal foundation, not the full RPG universe. It does not yet include player-to-player chat, auctions, equipment management, quest progression, guilds, payment processing, admin/moderator panels or password reset. Those can be added as separate modules.

## Project checks

```bash
npm run build
```

The build requires installing dependencies first. Live auth, database transactions and WhatsApp code delivery require the environment variables and the matching bot command above.
