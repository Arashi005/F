"use client";

import { useCallback, useEffect, useMemo, useState } from "react";

const fmt = (n) => new Intl.NumberFormat("en").format(Number(n || 0));
const dateFmt = (v) => v ? new Date(v).toLocaleString() : "—";

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

function Brand() {
  return <div className="brand"><span className="brand-mark">✧</span><span><b>FRIEREN</b><small>ETERNAL JOURNEY</small></span></div>;
}

function Login({ onLogin }) {
  const [mode, setMode] = useState("code");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setNotice("");
    try {
      if (mode === "code") {
        await api("/api/auth/verify-code", { method: "POST", body: JSON.stringify({ phone, code }) });
      } else {
        await api("/api/auth/password", { method: "POST", body: JSON.stringify({ phone, password }) });
      }
      await onLogin();
    } catch (err) { setNotice(err.message); }
    finally { setBusy(false); }
  }

  return <main className="login-wrap">
    <div className="login-art">
      <div className="orbit orbit-one" /><div className="orbit orbit-two" />
      <span className="art-sigil">✧</span>
      <p className="eyebrow">THE ADVENTURER'S LEDGER</p>
      <h1>Every journey<br/><i>leaves a mark.</i></h1>
      <p className="art-copy">Your character, your rewards, your place in the world — gathered in one quiet corner of the continent.</p>
      <div className="art-foot"><span>EST. IN THE AGE OF MAGIC</span><span>VOL. 01</span></div>
    </div>
    <section className="login-panel">
      <Brand />
      <div className="login-heading"><p className="eyebrow">WELCOME BACK, ADVENTURER</p><h2>Enter the journal</h2><p>Sign in with your linked WhatsApp account.</p></div>
      <div className="auth-tabs">
        <button className={mode === "code" ? "active" : ""} onClick={() => setMode("code")}>WhatsApp code</button>
        <button className={mode === "password" ? "active" : ""} onClick={() => setMode("password")}>Password</button>
      </div>
      <form onSubmit={submit} className="auth-form">
        <label>WhatsApp number <span>Include country code</span></label>
        <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="2547XXXXXXXX" inputMode="tel" autoComplete="tel" required />
        {mode === "code" ? <>
          <label>Six-digit verification code</label>
          <input value={code} onChange={e => setCode(e.target.value)} placeholder="Enter code from the bot" inputMode="numeric" maxLength={6} required />
          <p className="form-hint">In WhatsApp, privately send <code>.webcode</code> to the RPG bot. The code expires after 10 minutes.</p>
        </> : <>
          <label>Password</label>
          <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Your saved password" autoComplete="current-password" required />
          <p className="form-hint">Create a password after your first WhatsApp-code sign-in.</p>
        </>}
        {notice && <div className="notice">{notice}</div>}
        <button className="primary-btn" disabled={busy}>{busy ? "Please wait…" : "Open my journal"} <span>↗</span></button>
      </form>
      <p className="login-note">No adventurer profile yet? Register in the WhatsApp bot first with <code>.register YourName</code>.</p>
      <p className="copyright">A QUIET PLACE BETWEEN ADVENTURES · 2026</p>
    </section>
  </main>;
}

function Stat({ label, value, icon }) {
  return <div className="stat"><span>{icon} {label}</span><b>{value}</b></div>;
}

export default function Home() {
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [tab, setTab] = useState("overview");
  const [shopItems, setShopItems] = useState([]);
  const [listings, setListings] = useState([]);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [password, setPassword] = useState("");
  const [marketItem, setMarketItem] = useState("");
  const [marketPrice, setMarketPrice] = useState("");

  const refresh = useCallback(async () => {
    const data = await api("/api/me");
    setUser(data.player);
    setTransactions(data.transactions || []);
  }, []);

  useEffect(() => { refresh().catch(() => {}); }, [refresh]);
  useEffect(() => {
    if (tab === "shop") api("/api/shop").then(d => setShopItems(d.items)).catch(e => setNotice(e.message));
    if (tab === "market") api("/api/market").then(d => setListings(d.listings)).catch(e => setNotice(e.message));
  }, [tab]);

  const claimed = useMemo(() => user ? !user.dailyAvailable : false, [user?.dailyAvailable]);

  async function act(fn, success) {
    setBusy(true); setNotice("");
    try { await fn(); await refresh(); setNotice(success); }
    catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }

  async function claim() {
    await act(() => api("/api/daily", { method: "POST" }), "120 EG added to your purse.");
  }
  async function buyNpc(itemId) {
    await act(() => api("/api/shop", { method: "POST", body: JSON.stringify({ itemId }) }), "Purchase added to your inventory.");
  }
  async function buyListing(id) {
    await act(async () => {
      await api("/api/market/buy", { method: "POST", body: JSON.stringify({ listingId: id }) });
      const d = await api("/api/market"); setListings(d.listings);
    }, "Market purchase complete.");
  }
  async function createListing(e) {
    e.preventDefault();
    await act(async () => {
      await api("/api/market", { method: "POST", body: JSON.stringify({ itemId: marketItem, price: Number(marketPrice) }) });
      const d = await api("/api/market"); setListings(d.listings);
      setMarketItem(""); setMarketPrice("");
    }, "Your item is now listed.");
  }
  async function savePassword(e) {
    e.preventDefault();
    await act(() => api("/api/auth/password", { method: "POST", body: JSON.stringify({ action: "set", password }) }), "Password saved for future sign-ins.");
    setPassword("");
  }
  async function logout() {
    await api("/api/auth/logout", { method: "POST" });
    setUser(null); setTab("overview");
  }

  if (!user) return <Login onLogin={refresh} />;

  const nav = [
    ["overview", "◫", "Overview"], ["profile", "♙", "Character"], ["shop", "⌂", "NPC Shop"],
    ["market", "⇄", "Player Market"], ["inventory", "▤", "Inventory"], ["history", "↗", "Transactions"], ["settings", "⚙", "Account"]
  ];

  return <div className="app-shell">
    <aside className="sidebar">
      <Brand />
      <div className="side-label">YOUR JOURNEY</div>
      <nav>{nav.map(([id, icon, label]) => <button key={id} className={tab === id ? "selected" : ""} onClick={() => { setTab(id); setNotice(""); }}><span>{icon}</span>{label}{tab === id && <i />}</button>)}</nav>
      <div className="sidebar-bottom"><div className="side-quote">“The world is wide.<br/>Take your time.”</div><div className="mini-user"><div className="avatar">{user.characterName?.slice(0,1) || "A"}</div><div><b>{user.characterName}</b><small>Level {user.level} · {user.rank}</small></div></div><button className="logout" onClick={logout}>↗ Sign out</button></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div><span className="eyebrow">ADVENTURER'S JOURNAL</span><h1>{nav.find(n => n[0] === tab)?.[2] || "Overview"}</h1></div><div className="wallet"><span>ELVEN GOLD</span><b>◈ {fmt(user.gold)} <small>EG</small></b></div></header>
      {notice && <div className="toast" role="status">{notice}<button onClick={() => setNotice("")}>×</button></div>}

      {tab === "overview" && <section className="content">
        <div className="welcome-row"><div><p className="eyebrow">A NEW DAY, A NEW PAGE</p><h2>Welcome back, {user.characterName}.</h2><p>Your journey is still unfolding. What will you do today?</p></div><div className="rank-seal"><span>✧</span><small>RANK</small><b>{user.rank}</b></div></div>
        <div className="daily-card"><div className="daily-icon">✧</div><div className="daily-copy"><p className="eyebrow">DAILY ALLOWANCE</p><h3>120 Elven Gold</h3><p>A small provision for the road ahead.</p></div><button disabled={claimed || busy} onClick={claim} className={claimed ? "claimed-btn" : "primary-btn"}>{claimed ? "Claimed today ✓" : "Claim reward ↗"}</button></div>
        <div className="stat-grid">
          <Stat icon="✦" label="Level" value={user.level}/><Stat icon="♜" label="Rank points" value={fmt(user.rankPoints)}/><Stat icon="⚔" label="Victories" value={fmt(user.wins)}/><Stat icon="✧" label="Monsters defeated" value={fmt(user.monstersDefeated)}/>
        </div>
        <div className="two-col"><div className="panel"><div className="panel-head"><div><p className="eyebrow">YOUR ADVENTURER</p><h3>Character summary</h3></div><button className="text-btn" onClick={() => setTab("profile")}>Full profile ↗</button></div><div className="character-line"><div className="character-avatar">✧</div><div><b>{user.characterName}</b><span>{user.race} · {user.className}</span></div><strong>Lv. {user.level}</strong></div><div className="progress-label"><span>Experience</span><b>{fmt(user.xp)} XP</b></div><div className="progress"><i style={{width: `${Math.min(100, user.xp % 100)}%`}}/></div><div className="quick-stats"><Stat label="HP" icon="♡" value={`${user.hp}/${user.maxHp}`}/><Stat label="MP" icon="◇" value={`${user.mp}/${user.maxMp}`}/></div></div>
          <div className="panel"><div className="panel-head"><div><p className="eyebrow">RECENT ACTIVITY</p><h3>Ledger entries</h3></div><button className="text-btn" onClick={() => setTab("history")}>View all ↗</button></div>{transactions.slice(0,5).map(t => <div className="ledger-row" key={t.transactionId}><span className="ledger-dot">✧</span><div><b>{t.note || t.type}</b><small>{dateFmt(t.createdAt)}</small></div><strong>{t.type?.includes("purchase") ? "−" : "+"}{fmt(t.amount)} EG</strong></div>)}{!transactions.length && <p className="empty">Your ledger is waiting for its first entry.</p>}</div></div>
      </section>}

      {tab === "profile" && <section className="content"><div className="section-intro"><p className="eyebrow">THE ADVENTURER</p><h2>Character details</h2><p>Your current standing and attributes, synced from the WhatsApp RPG.</p></div><div className="profile-banner"><div className="large-avatar">✧</div><div><p className="eyebrow">{user.rank} RANK ADVENTURER</p><h2>{user.characterName}</h2><p>{user.race} · {user.className} · Level {user.level}</p></div><div className="banner-gold">◈ {fmt(user.gold)} EG</div></div><div className="panel"><div className="panel-head"><h3>Attributes</h3><span className="muted">Live character data</span></div><div className="attribute-grid">{[["Health",user.hp+"/"+user.maxHp],["Mana",user.mp+"/"+user.maxMp],["Strength",user.strength],["Intelligence",user.intelligence],["Defense",user.defense],["Agility",user.agility],["Magic proficiency",user.magicProficiency],["Rank points",user.rankPoints]].map(([k,v]) => <div className="attribute" key={k}><span>{k}</span><b>{v}</b></div>)}</div></div></section>}

      {tab === "shop" && <section className="content"><div className="section-intro"><p className="eyebrow">THE TOWN MERCHANT</p><h2>Provisions for the road</h2><p>NPC stock with fixed prices in Elven Gold.</p></div><div className="shop-grid">{shopItems.map(item => <div className="item-card" key={item.itemId}><div className="item-icon">{item.itemId === "health-potion" ? "♡" : "◇"}</div><p className="eyebrow">CONSUMABLE</p><h3>{item.name}</h3><p>{item.description}</p><div className="item-buy"><b>◈ {fmt(item.price)} EG</b><button onClick={() => buyNpc(item.itemId)} disabled={busy}>Buy</button></div></div>)}</div></section>}

      {tab === "market" && <section className="content"><div className="section-intro"><p className="eyebrow">PLAYER-TO-PLAYER EXCHANGE</p><h2>The adventurers' market</h2><p>Trade items with other players. All sales use fictional Elven Gold.</p></div><div className="panel list-panel"><div className="panel-head"><h3>Active listings</h3><span className="muted">{listings.length} available</span></div>{listings.map(item => <div className="market-row" key={item._id}><div className="market-item-icon">✧</div><div className="market-info"><b>{item.itemName}</b><small>Listed by {item.sellerName}</small></div><strong>◈ {fmt(item.price)} EG</strong><button disabled={busy || item.isMine} onClick={() => buyListing(item._id)}>{item.isMine ? "Your listing" : "Buy"}</button></div>)}{!listings.length && <p className="empty">No active listings yet. Be the first to offer an item.</p>}</div><div className="panel create-listing"><div className="panel-head"><div><p className="eyebrow">SELL AN ITEM</p><h3>Create a listing</h3></div></div><form onSubmit={createListing} className="listing-form"><label>Inventory item<select value={marketItem} onChange={e => setMarketItem(e.target.value)} required><option value="">Choose an item</option>{user.inventory.filter(i => i.quantity > 0).map(i => <option value={i.itemId} key={i.itemId}>{i.name} · {i.quantity} owned</option>)}</select></label><label>Price in EG<input type="number" min="1" max="100000000" value={marketPrice} onChange={e => setMarketPrice(e.target.value)} placeholder="e.g. 150" required /></label><button className="primary-btn" disabled={busy || !user.inventory.some(i => i.quantity > 0)}>List item ↗</button></form><p className="form-hint">One item is removed from your inventory when listed. You receive the listed EG when another player buys it.</p></div></section>}

      {tab === "inventory" && <section className="content"><div className="section-intro"><p className="eyebrow">YOUR BELONGINGS</p><h2>Inventory</h2><p>Items currently held by your character.</p></div><div className="panel">{user.inventory.map((item, i) => <div className="inventory-row" key={item.itemId}><span className="inventory-symbol">▧</span><b>{item.name}</b><span>× {item.quantity}</span><small>{item.itemId}</small></div>)}{!user.inventory.length && <p className="empty">Your bag is light. Visit the NPC shop or market to find supplies.</p>}</div></section>}

      {tab === "history" && <section className="content"><div className="section-intro"><p className="eyebrow">ELVEN GOLD ACCOUNT</p><h2>Transaction history</h2><p>A record of rewards, purchases and player-market trades.</p></div><div className="panel">{transactions.map(t => <div className="ledger-row full-ledger" key={t.transactionId}><span className="ledger-dot">✧</span><div><b>{t.note || t.type}</b><small>{t.type} · {dateFmt(t.createdAt)}</small></div><strong>{t.type?.includes("purchase") ? "−" : "+"}{fmt(t.amount)} EG</strong></div>)}{!transactions.length && <p className="empty">No transactions recorded yet.</p>}</div></section>}

      {tab === "settings" && <section className="content"><div className="section-intro"><p className="eyebrow">ACCOUNT SECURITY</p><h2>Sign-in settings</h2><p>Keep your account protected and connected to your WhatsApp number.</p></div><div className="panel settings-panel"><p className="eyebrow">OPTIONAL PASSWORD</p><h3>{password ? "Set a password" : "Add password sign-in"}</h3><p className="muted">WhatsApp verification remains available. A password is an additional sign-in method for this adventurer account.</p><form onSubmit={savePassword} className="password-form"><input type="password" minLength={10} maxLength={72} value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 10 characters" required/><button className="primary-btn" disabled={busy}>Save password</button></form></div></section>}
      <footer className="main-footer"><span>✧ FRIEREN: ETERNAL JOURNEY</span><span>THE JOURNEY NEVER ENDS</span></footer>
    </main>
  </div>;
}
