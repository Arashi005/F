import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Player, Transaction } from "@/lib/models";
import { getSessionUserId } from "@/lib/auth";
import { publicPlayer } from "@/lib/game";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return jsonError("Sign in to continue.", 401);
    await connectDB();
    const player = await Player.findOne({ userId }).lean();
    if (!player) return jsonError("Player profile not found.", 404);
    const transactions = await Transaction.find({ userId }).select("transactionId type amount currency note createdAt -_id").sort({ createdAt: -1 }).limit(8).lean();
    const dayStart = new Date();
    dayStart.setHours(0, 0, 0, 0);
    const dailyAvailable = !player.dailyClaimAt || new Date(player.dailyClaimAt) < dayStart;
    return NextResponse.json({ player: { ...publicPlayer(player), dailyAvailable }, transactions });
  } catch (error) {
    console.error("me", error);
    return jsonError("Unable to load your adventurer profile.", 500);
  }
}
