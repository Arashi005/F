import { randomUUID } from "node:crypto";
import mongoose from "mongoose";
import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Player, Transaction } from "@/lib/models";
import { NPC_ITEMS } from "@/lib/game";
import { getSessionUserId } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({ items: NPC_ITEMS });
}

export async function POST(request) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Sign in to shop.", 401);
  try {
    const { itemId } = await request.json();
    const item = NPC_ITEMS.find((entry) => entry.itemId === itemId);
    if (!item) return jsonError("That item is not sold here.", 404);
    await connectDB();
    const session = await mongoose.startSession();
    let updated;
    try {
      await session.withTransaction(async () => {
        updated = await Player.findOneAndUpdate(
          { userId, gold: { $gte: item.price } },
          { $inc: { gold: -item.price }, $push: { inventory: { itemId: item.itemId, name: item.name, quantity: 1 } } },
          { new: true, session }
        );
        if (!updated) throw new Error("Not enough Elven Gold.");
        await Transaction.create([{
          transactionId: randomUUID(), userId, type: "purchase",
          amount: item.price, currency: "EG", note: `NPC shop: ${item.name}`
        }], { session });
      });
    } finally {
      await session.endSession();
    }
    return NextResponse.json({ ok: true, gold: updated.gold });
  } catch (error) {
    return jsonError(error.message === "Not enough Elven Gold." ? error.message : "Purchase failed. Please try again.", 400);
  }
}
