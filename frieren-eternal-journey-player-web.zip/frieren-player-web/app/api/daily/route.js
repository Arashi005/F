import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Player, Transaction } from "@/lib/models";
import { getSessionUserId } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function POST() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return jsonError("Sign in to claim your reward.", 401);
    await connectDB();
    const now = new Date();
    const start = new Date(now);
    start.setHours(0, 0, 0, 0);
    const player = await Player.findOneAndUpdate(
      { userId, $or: [{ dailyClaimAt: null }, { dailyClaimAt: { $lt: start } }] },
      { $inc: { gold: 120 }, $set: { dailyClaimAt: now } },
      { new: true }
    );
    if (!player) return jsonError("Your daily allowance has already been claimed. Return after the daily reset.", 409);
    await Transaction.create({
      transactionId: randomUUID(), userId, type: "daily-reward",
      amount: 120, currency: "EG", note: "Daily adventurer allowance"
    });
    return NextResponse.json({ ok: true, gold: player.gold, reward: 120 });
  } catch (error) {
    console.error("daily", error);
    return jsonError("Could not process the daily reward.", 500);
  }
}
