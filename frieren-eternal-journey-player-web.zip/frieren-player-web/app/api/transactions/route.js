import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Transaction } from "@/lib/models";
import { getSessionUserId } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function GET() {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Sign in first.", 401);
  await connectDB();
  const transactions = await Transaction.find({ userId }).select("transactionId type amount currency note createdAt -_id").sort({ createdAt: -1 }).limit(30).lean();
  return NextResponse.json({ transactions });
}
