import mongoose from "mongoose";
import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { MarketListing, Player, Transaction } from "@/lib/models";
import { getSessionUserId } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function POST(request) {
  const buyerId = await getSessionUserId();
  if (!buyerId) return jsonError("Sign in to buy from the market.", 401);
  try {
    const { listingId } = await request.json();
    if (!mongoose.isValidObjectId(listingId)) return jsonError("Invalid listing.");
    await connectDB();
    const session = await mongoose.startSession();
    try {
      await session.withTransaction(async () => {
        const listing = await MarketListing.findOneAndUpdate(
          { _id: listingId, status: "active", sellerId: { $ne: buyerId } },
          { $set: { status: "sold", buyerId } },
          { new: true, session }
        );
        if (!listing) throw new Error("This listing is no longer available.");
        const buyer = await Player.findOneAndUpdate(
          { userId: buyerId, gold: { $gte: listing.price } },
          { $inc: { gold: -listing.price }, $push: { inventory: { itemId: listing.itemId, name: listing.itemName, quantity: 1 } } },
          { new: true, session }
        );
        if (!buyer) throw new Error("Not enough Elven Gold.");
        const seller = await Player.findOneAndUpdate(
          { userId: listing.sellerId },
          { $inc: { gold: listing.price } },
          { new: true, session }
        );
        if (!seller) throw new Error("Seller account no longer exists.");
        await Transaction.create([
          { transactionId: randomUUID(), userId: buyerId, type: "market-purchase", amount: listing.price, currency: "EG", note: listing.itemName },
          { transactionId: randomUUID(), userId: listing.sellerId, type: "market-sale", amount: listing.price, currency: "EG", note: listing.itemName }
        ], { session });
      });
    } finally {
      await session.endSession();
    }
    return NextResponse.json({ ok: true });
  } catch (error) {
    return jsonError(error.message || "Purchase failed.", 400);
  }
}
