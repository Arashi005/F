import mongoose from "mongoose";
import { randomUUID } from "node:crypto";
import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { MarketListing, Player, Transaction } from "@/lib/models";
import { getSessionUserId } from "@/lib/auth";
import { jsonError, safeInt } from "@/lib/http";

export const runtime = "nodejs";

export async function GET() {
  try {
    await connectDB();
    const viewerId = await getSessionUserId();
    const rows = await MarketListing.find({ status: "active" }).sort({ createdAt: -1 }).limit(60).lean();
    const listings = rows.map(({ _id, sellerName, sellerId, itemId, itemName, price, createdAt }) => ({
      _id: String(_id), sellerName, itemId, itemName, price, createdAt,
      isMine: Boolean(viewerId && sellerId === viewerId)
    }));
    return NextResponse.json({ listings });
  } catch (error) {
    console.error("market-get", error);
    return jsonError("Market is unavailable.", 500);
  }
}

export async function POST(request) {
  const userId = await getSessionUserId();
  if (!userId) return jsonError("Sign in to list an item.", 401);
  try {
    const { itemId, price } = await request.json();
    const amount = safeInt(price, 1, 100000000);
    if (!amount) return jsonError("Set a whole-number price greater than zero.");
    await connectDB();
    const session = await mongoose.startSession();
    let listing;
    try {
      await session.withTransaction(async () => {
        const player = await Player.findOne({ userId }).session(session);
        if (!player) throw new Error("Player not found.");
        const item = player.inventory.find((entry) => entry.itemId === itemId && entry.quantity > 0);
        if (!item) throw new Error("That item is not in your inventory.");
        item.quantity -= 1;
        player.inventory = player.inventory.filter((entry) => entry.quantity > 0);
        await player.save({ session });
        listing = await MarketListing.create([{
          sellerId: userId, sellerName: player.characterName,
          itemId: item.itemId, itemName: item.name, price: amount
        }], { session });
        listing = listing[0];
      });
    } finally {
      await session.endSession();
    }
    return NextResponse.json({ ok: true, listing: { id: String(listing._id), itemName: listing.itemName, price: listing.price } });
  } catch (error) {
    return jsonError(error.message || "Could not create listing.", 400);
  }
}
