import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { connectDB } from "@/lib/db";
import { Player, WebCredential } from "@/lib/models";
import { allowAuthAttempt, createSession, getSessionUserId, normalizePhone } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function POST(request) {
  try {
    const body = await request.json();
    await connectDB();

    if (body.action === "set") {
      const userId = await getSessionUserId();
      if (!userId) return jsonError("Sign in with a WhatsApp code before creating a password.", 401);
      const password = String(body.password || "");
      if (password.length < 10 || password.length > 72) return jsonError("Use a password between 10 and 72 characters.");
      const passwordHash = await bcrypt.hash(password, 12);
      await WebCredential.findOneAndUpdate(
        { userId },
        { $set: { passwordHash, updatedAt: new Date() } },
        { upsert: true, new: true }
      );
      return NextResponse.json({ ok: true, message: "Password saved. You can use it for future sign-ins." });
    }

    const userId = normalizePhone(body.phone);
    const password = String(body.password || "");
    if (userId.length < 8 || !password) return jsonError("Enter your WhatsApp number and password.");
    if (!(await allowAuthAttempt(userId, "password"))) return jsonError("Too many attempts. Wait 15 minutes before trying again.", 429);
    const player = await Player.findOne({ userId });
    const credential = await WebCredential.findOne({ userId });
    if (!player || !credential || !(await bcrypt.compare(password, credential.passwordHash))) {
      return jsonError("Phone number or password is incorrect.", 401);
    }
    await createSession(userId);
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("password-auth", error);
    return jsonError("Could not complete password sign-in.", 500);
  }
}
