import { NextResponse } from "next/server";
import { connectDB } from "@/lib/db";
import { Player, WebLoginCode } from "@/lib/models";
import { allowAuthAttempt, createSession, hashWebCode, normalizePhone } from "@/lib/auth";
import { jsonError } from "@/lib/http";

export const runtime = "nodejs";

export async function POST(request) {
  try {
    const { phone, code } = await request.json();
    const userId = normalizePhone(phone);
    const cleanCode = String(code || "").replace(/\D/g, "");
    if (userId.length < 8 || cleanCode.length !== 6) return jsonError("Enter your WhatsApp number and six-digit code.");
    await connectDB();
    if (!(await allowAuthAttempt(userId, "whatsapp-code"))) return jsonError("Too many attempts. Wait 15 minutes before trying again.", 429);
    const player = await Player.findOne({ userId });
    if (!player) return jsonError("No adventurer is registered to this WhatsApp number. Register in the bot first.", 404);
    const codeHash = hashWebCode(cleanCode);
    const challenge = await WebLoginCode.findOneAndUpdate(
      { userId, codeHash, consumedAt: null, expiresAt: { $gt: new Date() } },
      { $set: { consumedAt: new Date() } },
      { new: true }
    );
    if (!challenge) return jsonError("That code is invalid, expired, or already used.", 401);
    await createSession(userId);
    return NextResponse.json({ ok: true, player: { characterName: player.characterName } });
  } catch (error) {
    console.error("verify-code", error);
    return jsonError("Could not verify the code. Check server configuration.", 500);
  }
}
