import "./globals.css";

export const metadata = {
  title: "Frieren: Eternal Journey",
  description: "The adventurer's ledger — profile, rewards, market and inventory.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
