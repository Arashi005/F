# Railway bot integration: `.webcode`

This website authenticates players through the bot. The existing bot's `getUserId()` function already produces the digits-only phone number expected by the website.

1. Add the `WebLoginCode` Mongoose model from the main README to `src/database/models.js`.
2. Add the imports and `case 'webcode'` snippet from the main README to the bot command handler.
3. Add the same `WEB_CODE_SECRET` value to Railway and Vercel.
4. Redeploy the bot and website.
5. Test `.webcode` in a private bot chat.

Do not print the raw code to Railway logs. The bot should only send it to the requesting player's private chat.
